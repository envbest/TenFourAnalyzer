"use strict";
(() => {
  // src/core/types.ts
  function units(x) {
    if (typeof x !== "number" || !Number.isFinite(x) || Math.abs(x) > 1e8) return null;
    const n = Math.round(x * 100);
    return Math.abs(x * 100 - n) < 1e-5 ? n : null;
  }
  var cards = (x) => Array.isArray(x) ? x.filter((c) => typeof c === "string" && /^[2-9TJQKA][cdhs]$/.test(c)) : [];

  // src/core/adapter.ts
  var obj = (x) => x && typeof x === "object" && !Array.isArray(x) ? x : {};
  function positions(seats, button) {
    const occupied = seats.map((s, i) => s ? i : -1).filter((i) => i >= 0);
    const sorted = occupied.sort((a, b) => (a - button + seats.length) % seats.length - (b - button + seats.length) % seats.length);
    const labels = sorted.length === 2 ? ["BTN/SB", "BB"] : ["BTN", "SB", "BB", ...["UTG", "HJ", "CO"].slice(6 - sorted.length)];
    return new Map(sorted.map((seat, i) => [seat, labels[i] ?? "?"]));
  }
  function parseLines(lines, players) {
    const actions = [];
    const issues = [];
    let street = "preflop";
    let paid = /* @__PURE__ */ new Map();
    let high = 0;
    const stacks = new Map(players.map((p) => [p.seat, p.start ?? Infinity]));
    let section = "actions";
    for (const raw of lines) {
      const marker = raw.match(/^#\s*(PREFLOP|FLOP|TURN|RIVER)\b/i);
      if (marker) {
        section = "actions";
        street = marker[1].toLowerCase();
        paid = /* @__PURE__ */ new Map();
        high = 0;
        continue;
      }
      if (/^#\s*SHOWDOWN\b/i.test(raw)) {
        section = "showdown";
        continue;
      }
      if (/^#\s*RESULTS?\b/i.test(raw)) {
        section = "results";
        continue;
      }
      if (section === "showdown" && /^(UTG|HJ|CO|BTN(?:\/SB)?|SB|BB): (High Card|One Pair|Two Pair|Three of a Kind|Straight|Flush|Full House|Four of a Kind|Straight Flush|Royal Flush)$/i.test(raw)) continue;
      if (section === "results" && /^(UTG|HJ|CO|BTN(?:\/SB)?|SB|BB|Rake): [+-]?\d+(?:\.\d+)?bb$/i.test(raw)) continue;
      if (/^#.*(?:SHOWDOWN|RESULT|wins|Split pot|HAND)/i.test(raw)) continue;
      const m = raw.match(/^(UTG|HJ|CO|BTN(?:\/SB)?|SB|BB)\s+(POST(?:\s+(?:SB|BB))?|FOLD|CHECK|CALL|RAISE|BET|ALL-IN|RETURN)\s*(?:\(?([\d.]+)(?:bb)?\)?)?\s*$/i);
      if (!m) {
        issues.push(`\u672A\u5BFE\u5FDC\u306E\u30A2\u30AF\u30B7\u30E7\u30F3\u8868\u8A18: ${raw.slice(0, 100)}`);
        continue;
      }
      const p = players.find((p2) => p2.position === m[1] || m[1] === "SB" && p2.position === "BTN/SB");
      if (!p) {
        issues.push(`\u5E2D\u304C\u4E0D\u660E: ${m[1]}`);
        continue;
      }
      const verb = m[2].toUpperCase(), old = paid.get(p.seat) ?? 0, remaining = stacks.get(p.seat) ?? Infinity;
      const value = m[3] === void 0 ? null : units(Number(m[3]));
      let kind;
      let amount = 0;
      let to;
      if (verb === "FOLD") kind = "fold";
      else if (verb === "CHECK") kind = "check";
      else if (verb.startsWith("POST")) {
        kind = p.position === "BB" ? "bb" : "sb";
        amount = value ?? -1;
      } else if (verb === "CALL") {
        kind = "call";
        amount = value ?? Math.min(remaining, Math.max(0, high - old));
      } else if (verb === "RETURN") {
        kind = "return";
        amount = value ?? -1;
      } else {
        kind = verb === "BET" ? "bet" : verb === "ALL-IN" ? value !== null && value <= high ? "call" : high === 0 ? "bet" : "raise" : "raise";
        to = value ?? void 0;
        amount = value === null ? -1 : value - old;
      }
      if (amount < 0) {
        issues.push(`\u91D1\u984D\u3092\u89E3\u91C8\u3067\u304D\u307E\u305B\u3093: ${raw}`);
        continue;
      }
      if (kind === "return") paid.set(p.seat, old - amount);
      else paid.set(p.seat, old + amount);
      stacks.set(p.seat, remaining + (kind === "return" ? amount : -amount));
      high = Math.max(0, ...paid.values());
      actions.push({ street, seat: p.seat, kind, amount, ...to !== void 0 ? { to } : {}, ...verb === "ALL-IN" || kind !== "return" && amount > 0 && amount === remaining ? { allIn: true } : {} });
    }
    return { actions, issues: [...new Set(issues)] };
  }
  function recordKey(c) {
    const p = obj(c.payload);
    const id = p.tableId;
    if (typeof id !== "string" || !id || id.length > 160) return null;
    const mode = c.event.startsWith("expert") ? "expert" : c.event.startsWith("private") ? "private" : "normal";
    const hand = typeof p.handId === "string" && p.handId.length > 0 && p.handId.length <= 100 ? p.handId : null;
    return `${mode}:${id}${hand ? `:${hand}` : ""}`;
  }
  function fromSnapshot(c, previous) {
    const p = obj(c.payload), key = recordKey(c);
    if (!key || !Array.isArray(p.seats) || p.seats.length < 2 || p.seats.length > 9) return null;
    const at = c.at, button = Number.isInteger(p.buttonPosition) ? p.buttonPosition : null;
    const pos = positions(p.seats, button ?? 0);
    const lines = Array.isArray(p.actionHistory) ? p.actionHistory.filter((x) => typeof x === "string") : [];
    const results = Array.isArray(p.handResults) ? p.handResults.map(obj) : [];
    const cardIssues = [];
    const players = p.seats.flatMap((s, i) => {
      if (!s) return [];
      const seat = obj(s);
      const old = previous?.players.find((x) => x.seat === i);
      const visible = cards(seat.cards), revealed = cards(results.find((r) => r.seatIndex === i)?.hand);
      const known = visible.length ? visible : old?.cards ?? [];
      if (revealed.length === 2 && known.length === 2 && [...revealed].sort().join() !== [...known].sort().join()) cardIssues.push(`\u958B\u793A\u30AB\u30FC\u30C9\u304C\u53D7\u4FE1\u6E08\u307F\u30AB\u30FC\u30C9\u3068\u4E0D\u4E00\u81F4: ${pos.get(i) ?? i}`);
      return [{ seat: i, name: typeof seat.playerName === "string" ? seat.playerName : `Player ${i + 1}`, position: pos.get(i) ?? "?", uid: typeof seat.uid === "string" ? seat.uid : void 0, cards: revealed.length === 2 ? revealed : known, start: units(seat.initialChips) ?? units(seat.startingStack) ?? old?.start ?? null }];
    });
    const parsed = parseLines(lines, players);
    const opening = lines.length > 0 && parsed.issues.length === 0 && parsed.actions.every((a) => ["sb", "bb", "fold"].includes(a.kind)) && !cards(p.communityCards).length;
    if (opening) for (const player of players) {
      const chip = units(obj(p.seats[player.seat]).chips);
      if (chip !== null && player.start === null) player.start = chip + parsed.actions.filter((a) => a.seat === player.seat).reduce((n, a) => n + a.amount, 0);
    }
    const historyShrunk = previous && lines.length < previous.rawLines.length;
    if (historyShrunk) return { ...previous, updatedAt: at, issues: [.../* @__PURE__ */ new Set([...previous.issues, "\u540C\u3058\u5353ID\u3067\u5C65\u6B74\u306E\u5DFB\u304D\u623B\u308A\u3092\u691C\u51FA\u3002\u539F\u672C\u306E\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3059"])], status: "incomplete" };
    const heroSeat = Number.isInteger(p.mySeatIndex) ? p.mySeatIndex : previous?.heroSeat ?? null;
    const complete = results.length > 0;
    const issues = [...parsed.issues, ...cardIssues];
    const observedStacks = complete ? previous?.observedStacks : players.map((player) => ({ seat: player.seat, amount: units(obj(p.seats[player.seat]).chips) }));
    const payouts = [];
    let rake = null;
    if (complete && players.length >= 2 && results.length === players.length && new Set(results.map((r) => r.seatIndex)).size === players.length && results.every((r) => units(r.profit) !== null && players.some((p2) => p2.seat === r.seatIndex))) {
      const contributed = () => players.map((p2) => ({ seat: p2.seat, amount: parsed.actions.filter((a) => a.seat === p2.seat).reduce((n, a) => n + (a.kind === "return" ? -a.amount : a.amount), 0) })).sort((a, b) => b.amount - a.amount);
      const totals = contributed(), excess = totals[0].amount - totals[1].amount;
      const verifiedReset = p.isHandInProgress === false && players.every((player) => {
        const seat = obj(p.seats[player.seat]), spent = totals.find((t) => t.seat === player.seat).amount;
        return player.start !== null && units(seat.chips) === player.start && units(seat.initialChips) === player.start && observedStacks?.find((s) => s.seat === player.seat)?.amount === player.start - spent;
      });
      const lastStreet = parsed.actions.at(-1)?.street ?? "preflop";
      if (excess > 0 && !parsed.actions.some((a) => a.seat === totals[0].seat && a.kind === "fold")) parsed.actions.push({ seat: totals[0].seat, street: lastStreet, kind: "return", amount: excess });
      rake = -results.reduce((n, r) => n + (units(r.profit) ?? 0), 0);
      for (const r of results) {
        const player = players.find((p2) => p2.seat === r.seatIndex);
        const contribution = contributed().find((p2) => p2.seat === r.seatIndex).amount;
        const profit = units(r.profit), win = profit + contribution;
        if (win < 0 || r.isWinner === false && win !== 0) issues.push(`\u7CBE\u7B97\u7D50\u679C\u3068\u6295\u5165\u984D\u304C\u4E0D\u4E00\u81F4: ${player.position}`);
        if (win > 0) payouts.push({ seat: r.seatIndex, amount: win });
        const chips = units(obj(p.seats[r.seatIndex]).chips);
        if (player.start === null || chips === null || !verifiedReset && chips !== player.start - contribution && chips !== player.start + profit) issues.push(`\u7D42\u4E86\u30B9\u30BF\u30C3\u30AF\u3092\u7167\u5408\u3067\u304D\u307E\u305B\u3093: ${player.position}`);
      }
    } else if (complete) issues.push("\u5168\u30D7\u30EC\u30A4\u30E4\u30FC\u306E\u7CBE\u7B97\u7D50\u679C\u304C\u63C3\u3063\u3066\u3044\u307E\u305B\u3093");
    const heroResult = results.find((r) => r.seatIndex === heroSeat);
    const sourceId = typeof p.handId === "string" ? p.handId : previous?.sourceId ?? `table:${p.tableId}`;
    if (!complete) issues.push("\u7D42\u4E86\u7D50\u679C\u304C\u672A\u53D6\u5F97");
    return { id: key, sourceId, connection: c.connection, tableId: p.tableId, mode: key.startsWith("expert") ? "expert" : key.startsWith("private") ? "private" : "normal", startedAt: previous?.startedAt ?? at, updatedAt: at, heroSeat, button, players, board: cards(p.communityCards), actions: parsed.actions, payouts, rake, smallBlind: parsed.actions.find((a) => a.kind === "sb")?.amount ?? null, bigBlind: parsed.actions.find((a) => a.kind === "bb")?.amount ?? null, status: complete ? "complete" : "recording", issues, warnings: ["GTOWizard\u3067\u306E\u53D6\u308A\u8FBC\u307F\u691C\u8A3C\u306F\u672A\u5B9F\u65BD\u3067\u3059\u3002", ...sourceId.startsWith("table:") ? ["\u51FA\u529BID\u306F\u5353ID\u304B\u3089\u751F\u6210\u3057\u307E\u3059\u3002\u65E5\u6642\u306F\u6700\u521D\u306E\u53D7\u4FE1\u6642\u523B\u3067\u3059\u3002"] : []], rawLines: lines, profit: units(heroResult?.profit), ...observedStacks ? { observedStacks } : {}, ...previous?.revealedAt ? { revealedAt: previous.revealedAt } : {} };
  }

  // src/core/betting.ts
  function validateBettingOrder(h) {
    const problems = [];
    const seats = h.players.map((p) => p.seat).sort((a, b) => a - b);
    const stacks = new Map(h.players.map((p) => [p.seat, p.start ?? 0]));
    const folded = /* @__PURE__ */ new Set();
    let paid = /* @__PURE__ */ new Map();
    let street = "preflop", current = 0, lastRaise = h.bigBlind ?? 0, decisions = false, returned = false;
    let faced = /* @__PURE__ */ new Map();
    let pending = /* @__PURE__ */ new Set();
    let cursor = h.actions.find((a) => a.kind === "bb")?.seat ?? h.button ?? 0;
    const active = () => seats.filter((s) => !folded.has(s) && (stacks.get(s) ?? 0) > 0);
    const stillIn = () => seats.filter((s) => !folded.has(s));
    const next = () => {
      for (let step = 1; step <= seats.length; step++) {
        const s = seats[(seats.indexOf(cursor) + step) % seats.length];
        if (pending.has(s) && !folded.has(s) && (stacks.get(s) ?? 0) > 0) return s;
      }
      return void 0;
    };
    const unfinished = () => stillIn().length > 1 && [...pending].some((s) => !folded.has(s) && (stacks.get(s) ?? 0) > 0);
    for (const a of h.actions) {
      if (a.street !== street) {
        if (unfinished()) problems.push("\u524D\u306E\u30B9\u30C8\u30EA\u30FC\u30C8\u306E\u30A2\u30AF\u30B7\u30E7\u30F3\u304C\u5B8C\u4E86\u3057\u3066\u3044\u307E\u305B\u3093");
        street = a.street;
        paid = /* @__PURE__ */ new Map();
        faced = /* @__PURE__ */ new Map();
        current = 0;
        lastRaise = h.bigBlind ?? 0;
        cursor = h.button ?? 0;
        decisions = true;
        const eligible = active();
        pending = new Set(eligible.length > 1 ? eligible : []);
      }
      if (a.kind === "sb" || a.kind === "bb") {
        if (decisions) problems.push("\u30D6\u30E9\u30A4\u30F3\u30C9\u6295\u7A3F\u306E\u9806\u5E8F\u304C\u4E0D\u6B63\u3067\u3059");
        paid.set(a.seat, (paid.get(a.seat) ?? 0) + a.amount);
        stacks.set(a.seat, (stacks.get(a.seat) ?? 0) - a.amount);
        current = Math.max(current, paid.get(a.seat));
        continue;
      }
      if (a.kind === "return") {
        const ranked = [...paid.entries()].sort((a2, b) => b[1] - a2[1]);
        if (!ranked.length || ranked[0][0] !== a.seat || a.amount !== ranked[0][1] - (ranked[1]?.[1] ?? 0)) problems.push("\u8FD4\u5374\u984D\u304C\u672A\u30B3\u30FC\u30EB\u5206\u3068\u4E00\u81F4\u3057\u307E\u305B\u3093");
        returned = true;
        paid.set(a.seat, (paid.get(a.seat) ?? 0) - a.amount);
        continue;
      }
      if (returned) problems.push("\u8FD4\u5374\u5F8C\u306B\u30A2\u30AF\u30B7\u30E7\u30F3\u304C\u7D9A\u3044\u3066\u3044\u307E\u3059");
      if (!decisions) {
        decisions = true;
        pending = new Set(active());
      }
      if (stillIn().length < 2) problems.push("\u52DD\u8005\u78BA\u5B9A\u5F8C\u306B\u30A2\u30AF\u30B7\u30E7\u30F3\u304C\u7D9A\u3044\u3066\u3044\u307E\u3059");
      if (next() !== a.seat) problems.push("\u30A2\u30AF\u30B7\u30E7\u30F3\u9806\u5E8F\u304C\u4E0D\u6B63\u307E\u305F\u306F\u9014\u4E2D\u306E\u30A2\u30AF\u30B7\u30E7\u30F3\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u307E\u3059");
      const old = paid.get(a.seat) ?? 0, remaining = stacks.get(a.seat) ?? 0, newTotal = old + a.amount;
      if (a.kind === "bet" || a.kind === "raise") {
        if (faced.has(a.seat) && current - faced.get(a.seat) < lastRaise) problems.push("\u30B7\u30E7\u30FC\u30C8\u30AA\u30FC\u30EB\u30A4\u30F3\u5F8C\u306E\u30EC\u30A4\u30BA\u6A29\u304C\u3042\u308A\u307E\u305B\u3093");
        const increment = newTotal - current;
        if (increment < lastRaise && a.amount !== remaining) problems.push("\u6700\u5C0F\u30EC\u30A4\u30BA\u984D\u3092\u6E80\u305F\u3057\u3066\u3044\u307E\u305B\u3093");
        if (increment >= lastRaise) lastRaise = increment;
        current = newTotal;
        pending = new Set(active().filter((s) => s !== a.seat));
      }
      if (a.kind === "fold") folded.add(a.seat);
      else if (a.kind !== "check" || current > 0) faced.set(a.seat, current);
      pending.delete(a.seat);
      cursor = a.seat;
      paid.set(a.seat, newTotal);
      stacks.set(a.seat, remaining - a.amount);
    }
    if (unfinished()) problems.push("\u6700\u7D42\u30B9\u30C8\u30EA\u30FC\u30C8\u306E\u30A2\u30AF\u30B7\u30E7\u30F3\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u307E\u3059");
    const sb = h.actions.find((a) => a.kind === "sb"), bb = h.actions.find((a) => a.kind === "bb");
    if (sb && bb && h.button !== null) {
      const after = (s) => seats[(seats.indexOf(s) + 1) % seats.length];
      if (sb.seat !== (seats.length === 2 ? h.button : after(h.button)) || bb.seat !== after(sb.seat)) problems.push("\u30D6\u30E9\u30A4\u30F3\u30C9\u3068\u30DC\u30BF\u30F3\u306E\u4F4D\u7F6E\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
    }
    return [...new Set(problems)];
  }

  // src/core/pots.ts
  function rankFive(cards2) {
    const values = cards2.map((c) => "23456789TJQKA".indexOf(c[0]) + 2).sort((a, b) => b - a);
    const groups = [...new Set(values)].map((v) => ({ v, n: values.filter((x) => x === v).length })).sort((a, b) => b.n - a.n || b.v - a.v);
    const unique = [...new Set(values)], flush = cards2.every((c) => c[1] === cards2[0][1]);
    const straight = unique.length === 5 ? unique[0] - unique[4] === 4 ? unique[0] : unique.join() === "14,5,4,3,2" ? 5 : 0 : 0;
    let score;
    if (flush && straight) score = [8, straight];
    else if (groups[0].n === 4) score = [7, groups[0].v, groups[1].v];
    else if (groups[0].n === 3 && groups[1].n === 2) score = [6, groups[0].v, groups[1].v];
    else if (flush) score = [5, ...values];
    else if (straight) score = [4, straight];
    else if (groups[0].n === 3) score = [3, ...groups.map((g) => g.v)];
    else if (groups[0].n === 2 && groups[1].n === 2) score = [2, ...groups.map((g) => g.v)];
    else if (groups[0].n === 2) score = [1, ...groups.map((g) => g.v)];
    else score = [0, ...values];
    while (score.length < 6) score.push(0);
    return score.reduce((n, v) => n * 15 + v, 0);
  }
  function rankSeven(cards2) {
    if (cards2.length !== 7 || new Set(cards2).size !== 7 || cards2.some((c) => !/^[2-9TJQKA][cdhs]$/.test(c))) return null;
    let best = 0;
    for (let a = 0; a < 7; a++) for (let b = a + 1; b < 7; b++) best = Math.max(best, rankFive(cards2.filter((_, i) => i !== a && i !== b)));
    return best;
  }
  function allocate(supplies, demands, allowed, bound) {
    const supply = [...supplies], demand = [...demands], lower = bound?.min ?? 0;
    if (bound) {
      supply[bound.p] -= lower;
      demand[bound.r] -= lower;
    }
    if (supply.some((n2) => n2 < 0) || demand.some((n2) => n2 < 0)) return null;
    const n = 2 + supply.length + demand.length, sink = n - 1, cap = Array.from({ length: n }, () => Array(n).fill(0));
    for (let p = 0; p < supply.length; p++) {
      cap[0][1 + p] = supply[p];
      for (let r = 0; r < demand.length; r++) if (allowed[p][r]) cap[1 + p][1 + supply.length + r] = bound?.p === p && bound.r === r ? (bound.max ?? supplies[p]) - lower : supplies[p];
    }
    demand.forEach((d, r) => cap[1 + supply.length + r][sink] = d);
    const initial = cap.map((row) => [...row]);
    let flow = 0;
    while (true) {
      const parent = Array(n).fill(-1), queue = [0];
      parent[0] = 0;
      for (let i = 0; i < queue.length && parent[sink] < 0; i++) for (let v = 0; v < n; v++) if (parent[v] < 0 && cap[queue[i]][v] > 0) {
        parent[v] = queue[i];
        queue.push(v);
      }
      if (parent[sink] < 0) break;
      let delta = Infinity;
      for (let v = sink; v !== 0; v = parent[v]) delta = Math.min(delta, cap[parent[v]][v]);
      for (let v = sink; v !== 0; v = parent[v]) {
        cap[parent[v]][v] -= delta;
        cap[v][parent[v]] += delta;
      }
      flow += delta;
    }
    if (flow !== supply.reduce((a, b) => a + b, 0) || flow !== demand.reduce((a, b) => a + b, 0)) return null;
    return supply.map((_, p) => demand.map((_2, r) => initial[1 + p][1 + supply.length + r] - cap[1 + p][1 + supply.length + r] + (bound?.p === p && bound.r === r ? lower : 0)));
  }
  function settlementPots(h) {
    const fail = (issue) => ({ pots: [], issues: [issue] });
    const folded = new Set(h.actions.filter((a) => a.kind === "fold").map((a) => a.seat));
    const totals = h.players.map((p) => ({ seat: p.seat, amount: h.actions.filter((a) => a.seat === p.seat).reduce((n, a) => n + (a.kind === "return" ? -a.amount : a.amount), 0) }));
    if (totals.some((t) => !Number.isSafeInteger(t.amount) || t.amount < 0)) return fail("\u30DD\u30C3\u30C8\u3078\u306E\u6295\u5165\u984D\u304C\u4E0D\u6B63\u3067\u3059");
    const levels = [...new Set(totals.map((t) => t.amount).filter((n) => n > 0))].sort((a, b) => a - b), pots = [];
    let previous = 0;
    for (const level of levels) {
      const contributors = totals.filter((t) => t.amount >= level), eligible = contributors.filter((t) => !folded.has(t.seat)).map((t) => t.seat).sort((a, b) => a - b);
      const amount = (level - previous) * contributors.length;
      previous = level;
      if (!eligible.length) return fail("\u7372\u5F97\u3067\u304D\u308B\u30D7\u30EC\u30A4\u30E4\u30FC\u304C\u3044\u306A\u3044\u30DD\u30C3\u30C8\u3067\u3059");
      if (contributors.length === 1) return fail("\u672A\u30B3\u30FC\u30EB\u5206\u306E\u8FD4\u5374\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u307E\u3059");
      const last = pots.at(-1);
      if (last && last.eligible.join() === eligible.join()) last.amount += amount;
      else pots.push({ amount, eligible, awards: [], rake: 0 });
    }
    if (!pots.length || h.rake === null || h.rake < 0 || !Number.isSafeInteger(h.rake) || h.payouts.some((w) => w.amount <= 0 || !Number.isSafeInteger(w.amount))) return fail("\u30DD\u30C3\u30C8\u306E\u7CBE\u7B97\u60C5\u5831\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u307E\u3059");
    const seats = [...new Set(h.payouts.map((w) => w.seat))], demands = seats.map((seat) => h.payouts.filter((w) => w.seat === seat).reduce((n, w) => n + w.amount, 0));
    const hasRake = h.rake > 0;
    if (hasRake) demands.push(h.rake);
    const winners = [];
    for (const pot of pots) {
      if (pot.eligible.length === 1) {
        winners.push(pot.eligible);
        continue;
      }
      const ranked = pot.eligible.map((seat) => ({ seat, rank: rankSeven([...h.board, ...h.players.find((p) => p.seat === seat).cards]) }));
      if (ranked.some((p) => p.rank === null)) {
        if (pots.length > 1) return fail("\u30B5\u30A4\u30C9\u30DD\u30C3\u30C8\u306E\u914D\u5206\u78BA\u8A8D\u306B\u5FC5\u8981\u306A\u516C\u958B\u30AB\u30FC\u30C9\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u307E\u3059");
        winners.push(pot.eligible);
        continue;
      }
      const best = Math.max(...ranked.map((p) => p.rank));
      winners.push(ranked.filter((p) => p.rank === best).map((p) => p.seat));
    }
    const allowed = pots.map((_, p) => demands.map((_2, r) => r === seats.length || winners[p].includes(seats[r])));
    const amounts = pots.map((p) => p.amount);
    const fixedSplit = pots.length > 1 && !hasRake;
    let allocation;
    if (fixedSplit) {
      allocation = pots.map((pot, p) => {
        const ordered = [...winners[p]];
        ordered.sort((a, b) => (a - (h.button ?? 0) + 8) % 9 - (b - (h.button ?? 0) + 8) % 9);
        const share = Math.floor(pot.amount / ordered.length), extra = pot.amount % ordered.length;
        return seats.map((seat) => {
          const i = ordered.indexOf(seat);
          return i < 0 ? 0 : share + (i < extra ? 1 : 0);
        });
      });
      if (allocation.some((row, p) => row.reduce((a, b) => a + b, 0) !== amounts[p]) || demands.some((n, r) => allocation.reduce((s, row) => s + row[r], 0) !== n)) allocation = null;
    } else allocation = allocate(amounts, demands, allowed);
    if (!allocation) return fail("\u7372\u5F97\u984D\u30FB\u30DD\u30C3\u30C8\u53C2\u52A0\u8CC7\u683C\u30FB\u516C\u958B\u30AB\u30FC\u30C9\u306E\u52DD\u6557\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
    if (pots.length > 1 && !fixedSplit) {
      for (let p = 0; p < pots.length; p++) for (let r = 0; r < demands.length; r++) if (allowed[p][r]) {
        const n = allocation[p][r];
        if (n > 0 && allocate(amounts, demands, allowed, { p, r, max: n - 1 }) || n < Math.min(amounts[p], demands[r]) && allocate(amounts, demands, allowed, { p, r, min: n + 1 })) return fail("\u30B5\u30A4\u30C9\u30DD\u30C3\u30C8\u3054\u3068\u306E\u7372\u5F97\u984D\u30FB\u30EC\u30FC\u30AD\u914D\u5206\u3092\u4E00\u610F\u306B\u78BA\u5B9A\u3067\u304D\u307E\u305B\u3093");
      }
    }
    for (let p = 0; p < pots.length; p++) {
      pots[p].awards = seats.flatMap((seat, r) => allocation[p][r] > 0 ? [{ seat, amount: allocation[p][r] }] : []);
      pots[p].rake = hasRake ? allocation[p][seats.length] : 0;
      if (winners[p].length > 1 && winners[p].every((seat) => h.players.find((p2) => p2.seat === seat)?.cards.length === 2) && h.board.length === 5) {
        const shares = winners[p].map((seat) => pots[p].awards.find((w) => w.seat === seat)?.amount ?? 0);
        if (Math.max(...shares) - Math.min(...shares) > 1) return fail("\u540C\u5F79\u306E\u30DD\u30C3\u30C8\u5206\u914D\u984D\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
      }
    }
    return { pots, issues: [] };
  }

  // src/core/export.ts
  function validateHand(h) {
    const errors = [...h.issues, ...validateBettingOrder(h)];
    const add = (s) => errors.push(s);
    if (h.status !== "complete") add("\u30CF\u30F3\u30C9\u304C\u5B8C\u4E86\u3057\u3066\u3044\u307E\u305B\u3093");
    if (!h.sourceId) add("\u30CF\u30F3\u30C9ID\u304C\u3042\u308A\u307E\u305B\u3093");
    if (!Number.isFinite(h.startedAt)) add("\u65E5\u6642\u304C\u4E0D\u6B63\u3067\u3059");
    if (h.players.length < 2 || h.players.length > 6) add("\u5BFE\u5FDC\u4EBA\u6570\u306F2\u301C6\u4EBA\u3067\u3059");
    const seats = new Set(h.players.map((p) => p.seat));
    if (seats.size !== h.players.length || h.players.some((p) => !Number.isInteger(p.seat) || p.seat < 0 || p.seat > 8)) add("\u5E2D\u756A\u53F7\u304C\u4E0D\u6B63\u3067\u3059");
    if (h.button === null || !seats.has(h.button)) add("\u30DC\u30BF\u30F3\u4F4D\u7F6E\u304C\u4E0D\u660E\u3067\u3059");
    const hero = h.players.find((p) => p.seat === h.heroSeat);
    if (!hero || hero.cards.length !== 2) add("\u81EA\u5206\u306E\u30AB\u30FC\u30C9\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u307E\u3059");
    if (h.players.some((p) => p.start === null || !Number.isSafeInteger(p.start) || p.start < 0)) add("\u958B\u59CB\u30B9\u30BF\u30C3\u30AF\u304C\u4E0D\u660E\u307E\u305F\u306F\u4E0D\u6B63\u3067\u3059");
    if (!h.smallBlind || !h.bigBlind || h.smallBlind >= h.bigBlind) add("\u30D6\u30E9\u30A4\u30F3\u30C9\u304C\u4E0D\u660E\u307E\u305F\u306F\u4E0D\u6B63\u3067\u3059");
    const allCards = [...h.board, ...h.players.flatMap((p) => p.cards)];
    if (allCards.some((c) => !/^[2-9TJQKA][cdhs]$/.test(c)) || new Set(allCards).size !== allCards.length || ![0, 3, 4, 5].includes(h.board.length) || h.players.some((p) => ![0, 2].includes(p.cards.length))) add("\u30AB\u30FC\u30C9\u306E\u679A\u6570\u30FB\u91CD\u8907\u30FB\u8868\u8A18\u304C\u4E0D\u6B63\u3067\u3059");
    if (h.rake === null || !Number.isSafeInteger(h.rake) || h.rake < 0) add("\u30EC\u30FC\u30AD\u304C\u4E0D\u660E\u307E\u305F\u306F\u4E0D\u6B63\u3067\u3059");
    const stacks = new Map(h.players.map((p) => [p.seat, p.start ?? 0]));
    const paid = /* @__PURE__ */ new Map();
    const folded = /* @__PURE__ */ new Set();
    let street = "preflop", high = 0, total = 0;
    let lastStreet = 0;
    const order = ["preflop", "flop", "turn", "river"];
    if (h.actions.filter((a) => a.kind === "sb").length !== 1 || h.actions.filter((a) => a.kind === "bb").length !== 1) add("\u30D6\u30E9\u30A4\u30F3\u30C9\u6295\u7A3F\u304C\u4E0D\u8DB3\u307E\u305F\u306F\u91CD\u8907\u3057\u3066\u3044\u307E\u3059");
    for (const a of h.actions) {
      const si = order.indexOf(a.street);
      if (si < lastStreet || si < 0) add("\u30B9\u30C8\u30EA\u30FC\u30C8\u9806\u5E8F\u304C\u4E0D\u6B63\u3067\u3059");
      lastStreet = si;
      if (({ preflop: 0, flop: 3, turn: 4, river: 5 }[a.street] ?? 99) > h.board.length) add("\u30B9\u30C8\u30EA\u30FC\u30C8\u306B\u5FC5\u8981\u306A\u30DC\u30FC\u30C9\u304C\u3042\u308A\u307E\u305B\u3093");
      if (a.street !== street) {
        street = a.street;
        paid.clear();
        high = 0;
      }
      if (!seats.has(a.seat) || folded.has(a.seat)) add("\u4E0D\u6B63\u306A\u5E2D\u307E\u305F\u306F\u30D5\u30A9\u30FC\u30EB\u30C9\u5F8C\u306E\u30A2\u30AF\u30B7\u30E7\u30F3\u3067\u3059");
      if (!Number.isSafeInteger(a.amount) || a.amount < 0) {
        add("\u6295\u5165\u984D\u304C\u4E0D\u6B63\u3067\u3059");
        continue;
      }
      const old = paid.get(a.seat) ?? 0, stack = stacks.get(a.seat) ?? 0;
      if (a.kind === "check" && (a.amount !== 0 || old !== high)) add("\u30C1\u30A7\u30C3\u30AF\u6642\u306E\u6295\u5165\u984D\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
      if (a.kind === "fold" && a.amount !== 0) add("\u30D5\u30A9\u30FC\u30EB\u30C9\u3067\u30C1\u30C3\u30D7\u3092\u6295\u5165\u3057\u3066\u3044\u307E\u3059");
      if (a.kind === "call" && a.amount !== Math.min(stack, high - old)) add("\u30B3\u30FC\u30EB\u984D\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
      if (a.kind === "bet" && (high !== 0 || a.amount === 0)) add("\u30D9\u30C3\u30C8\u984D\u307E\u305F\u306F\u30BF\u30A4\u30DF\u30F3\u30B0\u304C\u4E0D\u6B63\u3067\u3059");
      if (a.kind === "raise" && (old + a.amount <= high || a.to !== old + a.amount)) add("\u30EC\u30A4\u30BA\u984D\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
      if (a.kind === "return" && (a.amount > old || a.amount <= 0)) add("\u672A\u30B3\u30FC\u30EB\u5206\u306E\u8FD4\u5374\u984D\u304C\u4E0D\u6B63\u3067\u3059");
      if (a.kind === "sb" && (a.street !== "preflop" || a.amount !== h.smallBlind)) add("SB\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
      if (a.kind === "bb" && (a.street !== "preflop" || a.amount !== h.bigBlind)) add("BB\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
      if (!["sb", "bb", "fold", "check", "call", "bet", "raise", "return"].includes(a.kind)) add("\u672A\u5BFE\u5FDC\u306E\u30A2\u30AF\u30B7\u30E7\u30F3\u3067\u3059");
      const delta = a.kind === "return" ? -a.amount : a.amount;
      if (delta > stack) add("\u30B9\u30BF\u30C3\u30AF\u3092\u8D85\u3048\u308B\u6295\u5165\u3067\u3059");
      if (a.allIn && delta !== stack) add("\u30AA\u30FC\u30EB\u30A4\u30F3\u984D\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
      stacks.set(a.seat, stack - delta);
      paid.set(a.seat, old + delta);
      high = Math.max(0, ...paid.values());
      total += delta;
      if (a.kind === "fold") folded.add(a.seat);
    }
    if (h.payouts.length === 0 || h.payouts.some((p) => !seats.has(p.seat) || folded.has(p.seat) || !Number.isSafeInteger(p.amount) || p.amount <= 0)) add("\u7372\u5F97\u984D\u307E\u305F\u306F\u52DD\u8005\u304C\u4E0D\u6B63\u3067\u3059");
    if (total !== h.payouts.reduce((n, p) => n + p.amount, 0) + (h.rake ?? 0)) add("\u6295\u5165\u984D\u30FB\u7372\u5F97\u984D\u30FB\u30EC\u30FC\u30AD\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
    const active = h.players.filter((p) => !folded.has(p.seat));
    if (active.length > 1 && h.board.length !== 5) add("\u30B7\u30E7\u30FC\u30C0\u30A6\u30F3\u306E\u30DC\u30FC\u30C9\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u307E\u3059");
    if (active.length > 1 && h.payouts.some((w) => h.players.find((p) => p.seat === w.seat)?.cards.length !== 2)) add("\u30B7\u30E7\u30FC\u30C0\u30A6\u30F3\u306E\u52DD\u8005\u30AB\u30FC\u30C9\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u307E\u3059");
    const hs = h.heroSeat;
    if (h.profit !== null && hs !== null) {
      const spent = h.actions.filter((a) => a.seat === hs).reduce((n, a) => n + (a.kind === "return" ? -a.amount : a.amount), 0), won = h.payouts.filter((p) => p.seat === hs).reduce((n, p) => n + p.amount, 0);
      if (won - spent !== h.profit) add("\u81EA\u5206\u306E\u53CE\u652F\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
    }
    if (errors.length === 0) errors.push(...settlementPots(h).issues);
    return [...new Set(errors)];
  }

  // src/core/history.ts
  var object = (x) => x && typeof x === "object" && !Array.isArray(x) ? x : {};
  var sameCards = (a, b) => [...a].sort().join() === [...b].sort().join();
  function fromHistory(c, previous) {
    if (c.event !== "handDetail") return;
    const payload = object(c.payload), detail = object(payload.detail), result2 = object(detail.result);
    const startedAt = typeof detail.startedAt === "string" ? Date.parse(detail.startedAt) : NaN;
    const endedAt = typeof detail.createdAt === "string" ? Date.parse(detail.createdAt) : startedAt;
    if (detail.mode !== void 0 && detail.mode !== previous.mode) return;
    if (typeof payload.handId !== "string" || detail.id !== payload.handId || !Number.isFinite(startedAt) || !Number.isFinite(endedAt) || endedAt < startedAt || previous.startedAt < startedAt - 2e3 || previous.startedAt > endedAt + 2e3 || !Array.isArray(detail.players) || detail.players.length !== previous.players.length || !Array.isArray(result2.winners) || result2.winners.length === 0 || units(result2.rake) === null || result2.rake < 0) return;
    if (previous.sourceId && !previous.sourceId.startsWith("table:") && previous.sourceId !== detail.id) return;
    const players = detail.players.map(object), positions2 = new Set(players.map((p) => p.position));
    if (positions2.size !== players.length || players.some((p) => cards(p.cards).length !== 2 || units(p.profit) === null)) return;
    if (!result2.winners.every((w) => {
      const winner = object(w);
      return positions2.has(winner.position) && units(winner.amount) !== null && winner.amount > 0;
    })) return;
    const hero = previous.players.find((p) => p.seat === previous.heroSeat), revealedHero = players.find((p) => p.position === hero?.position);
    if (!hero || hero.cards.length !== 2 || !revealedHero || !sameCards(hero.cards, cards(revealedHero.cards))) return;
    const board = Array.isArray(detail.rounds) ? detail.rounds.flatMap((r) => cards(object(r).cards)) : [];
    if (previous.board.some((card, i) => board[i] !== card)) return;
    const allCards = [...board, ...players.flatMap((p) => cards(p.cards))];
    if (new Set(allCards).size !== allCards.length) return;
    const enriched = previous.players.map((p) => {
      const revealed = players.find((r) => r.position === p.position);
      if (!revealed || p.cards.length && !sameCards(p.cards, cards(revealed.cards))) return null;
      return { ...p, cards: cards(revealed.cards) };
    });
    if (enriched.some((p) => p === null)) return;
    const matched = { ...previous, sourceId: detail.id, players: enriched, revealedAt: c.at, updatedAt: Math.max(previous.updatedAt, c.at), warnings: previous.warnings.filter((s) => !s.startsWith("\u51FA\u529BID\u306F\u5353ID") && !s.startsWith("\u5C65\u6B74\u88DC\u5B8C\u3092\u4FDD\u7559")) };
    try {
      return completeHistory(detail, matched, c.at);
    } catch (error) {
      return { ...matched, warnings: [...matched.warnings, `\u5C65\u6B74\u88DC\u5B8C\u3092\u4FDD\u7559: ${error instanceof Error ? error.message : String(error)}`] };
    }
  }
  function completeHistory(detail, previous, at) {
    const fail = (message) => {
      throw new Error(message);
    };
    if (previous.players.some((p) => p.start === null)) fail("\u958B\u59CB\u30B9\u30BF\u30C3\u30AF\u304C\u672A\u53D6\u5F97\u3067\u3059");
    if (!Array.isArray(detail.rounds) || !detail.rounds.length) fail("\u30B9\u30C8\u30EA\u30FC\u30C8\u60C5\u5831\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u307E\u3059");
    const forced = previous.actions.filter((a) => a.kind === "sb" || a.kind === "bb");
    if (forced.length !== 2 || forced[0].kind !== "sb" || forced[1].kind !== "bb") fail("\u30D6\u30E9\u30A4\u30F3\u30C9\u304C\u672A\u53D6\u5F97\u3067\u3059");
    const actions = forced.map((a) => ({ ...a })), board = [];
    const stacks = new Map(previous.players.map((p) => [p.seat, p.start]));
    let paid = /* @__PURE__ */ new Map();
    for (const a of forced) {
      stacks.set(a.seat, stacks.get(a.seat) - a.amount);
      paid.set(a.seat, a.amount);
    }
    const streets = ["preflop", "flop", "turn", "river"];
    let last = -1, sawShowdown = false;
    const contribution = (seat) => actions.filter((a) => a.seat === seat).reduce((n, a) => n + (a.kind === "return" ? -a.amount : a.amount), 0);
    for (const value of detail.rounds) {
      const round = object(value), name = typeof round.street === "string" ? round.street.toLowerCase() : "";
      if (sawShowdown) fail("\u30B7\u30E7\u30FC\u30C0\u30A6\u30F3\u5F8C\u306B\u30B9\u30C8\u30EA\u30FC\u30C8\u304C\u7D9A\u3044\u3066\u3044\u307E\u3059");
      if (name === "showdown") {
        if (last < 0 || round.actions?.length) fail("\u672A\u5BFE\u5FDC\u306E\u30B7\u30E7\u30FC\u30C0\u30A6\u30F3\u30A2\u30AF\u30B7\u30E7\u30F3\u3067\u3059");
        sawShowdown = true;
        continue;
      }
      const index = streets.indexOf(name);
      if (index !== last + 1) fail("\u5C65\u6B74\u306E\u30B9\u30C8\u30EA\u30FC\u30C8\u304C\u4E0D\u8DB3\u307E\u305F\u306F\u91CD\u8907\u3057\u3066\u3044\u307E\u3059");
      last = index;
      if (!Array.isArray(round.actions)) fail("\u5C65\u6B74\u306E\u30A2\u30AF\u30B7\u30E7\u30F3\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u307E\u3059");
      const received = cards(round.cards);
      if (index > 0) {
        if (received.length !== (index === 1 ? 3 : 1)) fail("\u5C65\u6B74\u306E\u30DC\u30FC\u30C9\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u307E\u3059");
        board.push(...received);
        paid = /* @__PURE__ */ new Map();
        if (units(round.pot) !== previous.players.reduce((sum, p) => sum + contribution(p.seat), 0)) fail("\u30B9\u30C8\u30EA\u30FC\u30C8\u958B\u59CB\u6642\u306E\u30DD\u30C3\u30C8\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
      } else if (received.length) fail("\u30D7\u30EA\u30D5\u30ED\u30C3\u30D7\u306E\u30DC\u30FC\u30C9\u304C\u4E0D\u6B63\u3067\u3059");
      for (const value2 of round.actions) {
        const action = object(value2), player = previous.players.find((p) => p.position === action.position);
        if (!player) fail("\u5C65\u6B74\u306E\u5E2D\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
        const seat = player.seat, old = paid.get(seat) ?? 0, remaining = stacks.get(seat);
        const high = Math.max(0, ...paid.values()), verb = String(action.action).toLowerCase().replace(/[- ]/g, "");
        let kind, amount = 0, to;
        if (verb === "fold" || verb === "check") {
          kind = verb;
          if (action.amount !== void 0 && action.amount !== 0) fail("\u6295\u5165\u3092\u4F34\u308F\u306A\u3044\u30A2\u30AF\u30B7\u30E7\u30F3\u306B\u91D1\u984D\u304C\u3042\u308A\u307E\u3059");
        } else if (verb === "call" || verb === "bet" || verb === "raise" || verb === "allin") {
          const total = action.amount === void 0 && verb === "call" ? old + Math.min(remaining, high - old) : units(action.amount);
          if (total === null) fail("\u5C65\u6B74\u306E\u6295\u5165\u984D\u304C\u4E0D\u6B63\u3067\u3059");
          amount = total - old;
          kind = verb === "allin" ? total <= high ? "call" : high === 0 ? "bet" : "raise" : verb;
          if (kind === "raise") to = total;
        } else fail(`\u672A\u5BFE\u5FDC\u306E\u5C65\u6B74\u30A2\u30AF\u30B7\u30E7\u30F3: ${String(action.action).slice(0, 40)}`);
        if (amount < 0 || amount > remaining) fail("\u5C65\u6B74\u306E\u6295\u5165\u984D\u304C\u30B9\u30BF\u30C3\u30AF\u3068\u4E00\u81F4\u3057\u307E\u305B\u3093");
        const allIn = amount > 0 && amount === remaining;
        if ((verb === "allin" || action.allIn === true) && !allIn) fail("\u5C65\u6B74\u306E\u30AA\u30FC\u30EB\u30A4\u30F3\u984D\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
        actions.push({ seat, street: name, kind, amount, ...to === void 0 ? {} : { to }, ...allIn ? { allIn: true } : {} });
        paid.set(seat, old + amount);
        stacks.set(seat, remaining - amount);
      }
    }
    const prefix = previous.actions.filter((a) => a.kind !== "return");
    if (prefix.some((a, i) => {
      const b = actions[i];
      return !b || a.seat !== b.seat || a.street !== b.street || a.kind !== b.kind || a.amount !== b.amount || a.kind === "raise" && a.to !== b.to;
    })) fail("\u53D7\u4FE1\u6E08\u307F\u30A2\u30AF\u30B7\u30E7\u30F3\u3068\u5C65\u6B74\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
    if (previous.status !== "complete" && previous.observedStacks?.some((s) => {
      const p = previous.players.find((p2) => p2.seat === s.seat), spent = previous.actions.filter((a) => a.seat === s.seat).reduce((n, a) => n + (a.kind === "return" ? -a.amount : a.amount), 0);
      return !p || s.amount === null || s.amount !== p.start - spent;
    })) fail("\u53D7\u4FE1\u6E08\u307F\u30B9\u30BF\u30C3\u30AF\u3068\u6295\u5165\u984D\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
    const totals = previous.players.map((p) => ({ seat: p.seat, amount: contribution(p.seat) })).sort((a, b) => b.amount - a.amount);
    const excess = totals[0].amount - totals[1].amount;
    if (excess > 0 && !actions.some((a) => a.seat === totals[0].seat && a.kind === "fold")) actions.push({ seat: totals[0].seat, street: actions.at(-1).street, kind: "return", amount: excess });
    const result2 = object(detail.result);
    const payouts = result2.winners.map((value) => {
      const w = object(value);
      return { seat: previous.players.find((p) => p.position === w.position).seat, amount: units(w.amount) };
    });
    for (const p of previous.players) {
      const won = payouts.filter((w) => w.seat === p.seat).reduce((n, w) => n + w.amount, 0);
      const recorded = detail.players.find((r) => r.position === p.position);
      if (won - contribution(p.seat) !== units(recorded.profit)) fail(`\u5C65\u6B74\u306E\u53CE\u652F\u3068\u7372\u5F97\u984D\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093: ${p.position}`);
    }
    const hero = previous.players.find((p) => p.seat === previous.heroSeat);
    const candidate = { ...previous, actions, board, payouts, rake: units(result2.rake), status: "complete", issues: [], profit: units(detail.players.find((p) => p.position === hero.position).profit), historyCompletedAt: at };
    const issues = validateHand(candidate);
    if (issues.length) fail(issues.join(" / "));
    return candidate;
  }

  // src/core/reprocess.ts
  function applyCapture(c, previous) {
    if (previous && c.at < previous.updatedAt) return previous;
    if (c.event.endsWith("TableState")) {
      if (previous?.historyCompletedAt) return previous;
      const next = fromSnapshot(c, previous) ?? previous;
      return previous?.status === "complete" && next?.status !== "complete" ? previous : next;
    }
    if (previous?.connection && previous.connection !== c.connection) return previous;
    const removed = c.event.endsWith("TableRemoved");
    if (previous && (removed && previous.status !== "complete" || c.event === "connectionClosed" && previous.status === "recording")) {
      const issue = removed ? "\u5353\u304B\u3089\u9000\u51FA\u3002\u7D42\u4E86\u7D50\u679C\u306E\u88DC\u5B8C\u304C\u5FC5\u8981\u3067\u3059" : "\u63A5\u7D9A\u304C\u7D42\u4E86\u3057\u307E\u3057\u305F";
      return { ...previous, status: "incomplete", updatedAt: c.at, issues: [.../* @__PURE__ */ new Set([...previous.issues, issue])] };
    }
    return previous;
  }
  function removalMatches(c, h) {
    const key = recordKey(c);
    return !!key && (h.id === key || h.id.startsWith(key + ":")) && (!h.connection || h.connection === c.connection);
  }

  // src/core/protocol.ts
  var EVENTS = /* @__PURE__ */ new Set(["fastFoldTableState", "expertFastFoldTableState", "privateFastFoldTableState", "fastFoldTableRemoved", "expertFastFoldTableRemoved", "privateFastFoldTableRemoved", "fastFoldState", "expertFastFoldState", "privateFastFoldState"]);
  function sanitize(value, depth = 0) {
    if (depth > 20) return null;
    if (typeof value === "string") return value.slice(0, 2e4);
    if (typeof value === "number") return Number.isFinite(value) ? value : null;
    if (value === null || typeof value === "boolean") return value;
    if (Array.isArray(value)) return value.slice(0, 4e3).map((v) => sanitize(v, depth + 1));
    if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).filter(([k]) => !/(token|authorization|cookie|password|secret|email|credential|sessionid|__proto__|constructor|prototype)/i.test(k)).slice(0, 200).map(([k, v]) => [k, sanitize(v, depth + 1)]));
    return null;
  }
  function validCapture(value) {
    if (!value || typeof value !== "object") return false;
    const x = value;
    return typeof x.id === "string" && x.id.length > 0 && x.id.length <= 180 && typeof x.connection === "string" && x.connection.length > 0 && x.connection.length <= 180 && Number.isSafeInteger(x.at) && x.at >= 0 && Number.isFinite(new Date(x.at).getTime()) && (EVENTS.has(x.event) || x.event === "handDetail" || x.event === "connectionClosed") && !!x.payload && typeof x.payload === "object" && !Array.isArray(x.payload) && (x.sequence === void 0 || Number.isSafeInteger(x.sequence) && x.sequence >= 0);
  }

  // src/core/store.ts
  var DB = "tenfour-analyzer-v1";
  var opened = null;
  function database() {
    return opened ??= new Promise((resolve, reject) => {
      const req = indexedDB.open(DB, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        db.createObjectStore("events", { keyPath: "id" }).createIndex("connection", "connection");
        db.createObjectStore("hands", { keyPath: "id" });
        db.createObjectStore("annotations", { keyPath: "id" });
        db.createObjectStore("meta");
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => {
        opened = null;
        reject(req.error);
      };
    });
  }
  var result = (r) => new Promise((resolve, reject) => {
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
  var done = (tx) => new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error ?? new Error("\u4FDD\u5B58\u3092\u4E2D\u65AD\u3057\u307E\u3057\u305F"));
  });
  var initialStatus = { lastSeen: 0, lastSaved: 0, error: null, enabled: true, events: 0 };
  async function setStatus(patch) {
    const db = await database(), tx = db.transaction("meta", "readwrite"), end = done(tx), store = tx.objectStore("meta");
    const old = await result(store.get("status"));
    store.put({ ...initialStatus, ...old, ...patch }, "status");
    await end;
  }
  async function ingest(input) {
    if (!validCapture(input)) throw new Error("\u53D7\u4FE1\u30C7\u30FC\u30BF\u5F62\u5F0F\u304C\u4E0D\u6B63\u3067\u3059");
    const c = { ...input, payload: sanitize(input.payload) };
    const db = await database(), tx = db.transaction(["events", "hands", "meta"], "readwrite"), end = done(tx);
    try {
      const events = tx.objectStore("events"), hands = tx.objectStore("hands"), meta = tx.objectStore("meta");
      const current = await result(meta.get("status")) ?? initialStatus;
      if (!current.enabled) {
        await end;
        return;
      }
      if (await result(events.get(c.id))) {
        await end;
        return;
      }
      events.put(c);
      if (c.event === "handDetail") {
        const candidates = (await result(hands.getAll())).map((h) => fromHistory(c, h)).filter((h) => !!h);
        if (candidates.length === 1) hands.put(candidates[0]);
      }
      const key = recordKey(c);
      const ids = c.event === "connectionClosed" ? new Set((await result(events.index("connection").getAll(c.connection))).map(recordKey)) : c.event.endsWith("TableRemoved") ? new Set((await result(hands.getAll())).filter((h) => removalMatches(c, h)).map((h) => h.id)) : /* @__PURE__ */ new Set([key]);
      for (const id of ids) {
        if (!id) continue;
        const previous = await result(hands.get(id));
        const h = applyCapture(c, previous);
        if (h && h !== previous) hands.put(h);
      }
      meta.put({ ...current, lastSeen: c.at, lastSaved: Date.now(), events: current.events + 1, error: null }, "status");
      await end;
    } catch (error) {
      try {
        tx.abort();
      } catch {
      }
      await end.catch(() => {
      });
      throw error;
    }
  }

  // src/extension/background.ts
  chrome.action.onClicked.addListener(() => {
    void chrome.tabs.create({ url: chrome.runtime.getURL("index.html") });
  });
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (sender.id !== chrome.runtime.id || !sender.tab || !sender.url?.startsWith("https://tenfour-poker.com/")) return false;
    if (message.type === "capture") {
      ingest(message.capture).then(() => reply({ ok: true })).catch(async (error) => {
        const text = error instanceof Error ? error.message : "\u8A18\u9332\u306B\u5931\u6557\u3057\u307E\u3057\u305F";
        await setStatus({ error: text }).catch(() => {
        });
        reply({ ok: false, error: text });
      });
      return true;
    }
    if (message.type === "captureError") {
      void setStatus({ error: String(message.error).slice(0, 500) });
      reply({ ok: true });
    }
    return false;
  });
})();
