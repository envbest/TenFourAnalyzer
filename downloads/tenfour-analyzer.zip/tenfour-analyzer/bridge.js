"use strict";
(() => {
  // src/core/protocol.ts
  var EVENTS = /* @__PURE__ */ new Set(["fastFoldTableState", "expertFastFoldTableState", "privateFastFoldTableState", "fastFoldTableRemoved", "expertFastFoldTableRemoved", "privateFastFoldTableRemoved", "fastFoldState", "expertFastFoldState", "privateFastFoldState"]);
  function validCapture(value) {
    if (!value || typeof value !== "object") return false;
    const x = value;
    return typeof x.id === "string" && x.id.length > 0 && x.id.length <= 180 && typeof x.connection === "string" && x.connection.length > 0 && x.connection.length <= 180 && Number.isSafeInteger(x.at) && x.at >= 0 && Number.isFinite(new Date(x.at).getTime()) && (EVENTS.has(x.event) || x.event === "handDetail" || x.event === "connectionClosed") && !!x.payload && typeof x.payload === "object" && !Array.isArray(x.payload) && (x.sequence === void 0 || Number.isSafeInteger(x.sequence) && x.sequence >= 0);
  }

  // src/extension/bridge.ts
  var queue = [];
  var running = false;
  var retry = 0;
  async function flush() {
    if (running) return;
    running = true;
    try {
      while (queue.length) {
        const response = await chrome.runtime.sendMessage({ type: "capture", capture: queue[0] });
        if (!response?.ok) throw new Error(response?.error ?? "\u4FDD\u5B58\u5931\u6557");
        queue.shift();
        retry = 0;
      }
    } catch {
      retry++;
      setTimeout(flush, Math.min(3e4, 1e3 * 2 ** Math.min(retry, 5)));
    } finally {
      running = false;
    }
  }
  window.addEventListener("message", (e) => {
    if (e.source !== window || e.origin !== location.origin || e.data?.channel !== "tenfour-analyzer-capture-v1" || !validCapture(e.data.capture)) return;
    if (JSON.stringify(e.data.capture).length > 2e6) return;
    if (queue.length >= 1e3) {
      void chrome.runtime.sendMessage({ type: "captureError", error: "\u4FDD\u5B58\u5F85\u3061\u304C\u4E0A\u9650\u306B\u9054\u3057\u307E\u3057\u305F\u3002\u30DA\u30FC\u30B8\u3092\u9589\u3058\u305A\u306B\u8A18\u9332\u72B6\u6CC1\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002" }).catch(() => {
      });
      return;
    }
    queue.push(e.data.capture);
    void flush();
  });
})();
