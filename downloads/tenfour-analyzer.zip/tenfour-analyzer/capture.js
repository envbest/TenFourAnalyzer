"use strict";
(() => {
  // src/core/protocol.ts
  var EVENTS = /* @__PURE__ */ new Set(["fastFoldTableState", "expertFastFoldTableState", "privateFastFoldTableState", "fastFoldTableRemoved", "expertFastFoldTableRemoved", "privateFastFoldTableRemoved", "fastFoldState", "expertFastFoldState", "privateFastFoldState"]);
  function decodeFrames(raw) {
    const out = [];
    if (raw.length > 2e6) return out;
    for (const frame of raw.split("")) {
      const m = frame.match(/^42(?:\/[^,]*,)?\d*(\[.*)$/s);
      if (!m) continue;
      try {
        const value = JSON.parse(m[1]);
        if (Array.isArray(value) && EVENTS.has(value[0]) && value[1] && typeof value[1] === "object") out.push({ event: value[0], payload: value[1] });
      } catch {
      }
    }
    return out;
  }
  function sanitize(value, depth = 0) {
    if (depth > 20) return null;
    if (typeof value === "string") return value.slice(0, 2e4);
    if (typeof value === "number") return Number.isFinite(value) ? value : null;
    if (value === null || typeof value === "boolean") return value;
    if (Array.isArray(value)) return value.slice(0, 4e3).map((v) => sanitize(v, depth + 1));
    if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).filter(([k]) => !/(token|authorization|cookie|password|secret|email|credential|sessionid|__proto__|constructor|prototype)/i.test(k)).slice(0, 200).map(([k, v]) => [k, sanitize(v, depth + 1)]));
    return null;
  }

  // src/extension/capture.ts
  (() => {
    const CHANNEL = "tenfour-analyzer-capture-v1";
    let sequence = 0;
    const safeHost = (url) => {
      try {
        const u = new URL(url, location.href);
        return u.hostname === "game.tenfour-poker.com" && u.pathname.startsWith("/socket.io/");
      } catch {
        return false;
      }
    };
    const emit = (event, payload, connection) => {
      try {
        window.postMessage({ channel: CHANNEL, capture: { id: crypto.randomUUID(), at: Date.now(), sequence: sequence++, event, payload: sanitize(payload), connection } }, location.origin);
      } catch {
      }
    };
    const Original = window.WebSocket;
    window.WebSocket = new Proxy(Original, { construct(Target, args) {
      const socket = Reflect.construct(Target, args);
      if (safeHost(String(args[0]))) {
        const id = crypto.randomUUID();
        let chain = Promise.resolve();
        socket.addEventListener("message", (e) => {
          chain = chain.then(async () => {
            const raw = typeof e.data === "string" ? e.data : e.data instanceof Blob ? await e.data.text() : null;
            if (raw) for (const packet of decodeFrames(raw)) emit(packet.event, packet.payload, id);
          }).catch(() => {
          });
        });
        socket.addEventListener("close", () => {
          chain.then(() => emit("connectionClosed", {}, id)).catch(() => {
          });
        });
      }
      return socket;
    } });
    const originalFetch = window.fetch;
    window.fetch = function(...args) {
      const promise = Reflect.apply(originalFetch, this, args);
      try {
        const address = args[0] instanceof Request ? args[0].url : String(args[0]);
        const url = new URL(address, location.href);
        if (url.hostname === "game.tenfour-poker.com" && /^\/api\/hand\/[a-zA-Z0-9_-]+$/.test(url.pathname)) {
          void promise.then((response) => {
            if (response.ok) return response.clone().text().then((raw) => {
              if (raw.length < 2e6) emit("handDetail", { handId: url.pathname.split("/").at(-1), detail: JSON.parse(raw) }, "http");
            });
          }).catch(() => {
          });
        }
      } catch {
      }
      return promise;
    };
  })();
})();
